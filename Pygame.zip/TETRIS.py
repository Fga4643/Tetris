from random import randrange as random
import pygame
import sys
g = 0
config = {'cell_size': 20, 'cols': 24, 'rows': 34, 'delay': 400, 'maxfps': 200}

colors = [(20, 0, 244), (255, 0, 0), (0, 150, 0), (0, 0, 255),
    (255, 120, 0), (219, 215, 210), (252, 137, 172), (10, 186, 181),
    (93, 57, 84),
    (44, 117, 255), (20, 0, 244), (255, 0, 0), (0, 150, 0),
    (0, 0, 255), (255, 120, 0), (219, 215, 210),
    (252, 137, 172), (10, 186, 181), (93, 57, 84), (44, 117, 255),
    (20, 0, 244), (255, 0, 0), (0, 150, 0),
    (0, 0, 255), (255, 120, 0), (219, 215, 210), (252, 137, 172),
    (10, 186, 181), (93, 57, 84), (44, 117, 255)]
tetris_placer = [[[1, 1, 1],
    [0, 1, 0]], [[0, 2, 2],
    [2, 2, 0]], [[3, 3, 0],
    [0, 3, 3]], [[4, 0, 0],
    [4, 4, 4]], [[0, 0, 5],
    [5, 5, 5]], [[6, 6, 6, 6]],
    [[7, 7], [7, 7]],
    [[8, 8, 8, 8]],  [[1, 1, 1],
    [0, 1, 0]], [[0, 2, 2],
    [2, 2, 0]], [[3, 3, 0],
    [0, 3, 3]], [[4, 0, 0],
    [4, 4, 4]], [[0, 0, 5],
    [5, 5, 5]], [[6, 6, 6, 6]],
    [[7, 7], [7, 7]],
    [[8, 8, 8, 8]], [[1, 1, 1],
    [0, 1, 0]], [[0, 2, 2],
    [2, 2, 0]], [[3, 3, 0],
    [0, 3, 3]], [[4, 0, 0],
    [4, 4, 4]], [[0, 0, 5],
    [5, 5, 5]], [[6, 6, 6, 6]], [[7, 7], [7, 7]],
    [[8, 8, 8, 8]]]


def rotate_clockwise(place):
	return[[place[y][x]
        for y in range(len(place))]
            for x in range(len(place[0]) - 1, -1, -1)]


def check_collision(doska, place, ofset):
	of_x, of_y = ofset
	for cy, row in enumerate(place):
		for cx, cell in enumerate(row):
			try:
				if cell and doska[ cy + of_y ][ cx + of_x ]:
					return True
			except IndexError:
				return True
	return False

def remove_row(doska, row):
	del doska[row]
	return [[0 for i in range(config['cols'])]] + doska
	
def join_matrixes(mat1, mat2, mat2_of):
	of_x, of_y = mat2_of
	for cy, row in enumerate(mat2):
		for cx, val in enumerate(row):
			mat1[cy+of_y-1	][cx+of_x] += val
	return mat1

def new_doska():
	doska = [[ 0 for x in range(config['cols'])]
			for y in range(config['rows']) ]
	doska += [[ 1 for x in range(config['cols'])]]
	return doska

class TetrisApp(object):
	def __init__(self):
		pygame.init()
		pygame.key.set_repeat(250,25)
		self.width = config['cell_size']*config['cols']
		self.height = config['cell_size']*config['rows']
		
		self.screen = pygame.display.set_mode((self.width, self.height))
		pygame.event.set_blocked(pygame.MOUSEMOTION)
		self.init_game()
	
	def new_figur(self):
		global g
		self.figur = tetris_placer[random(len(tetris_placer))]
		self.figur_x = int(config['cols'] / 2 - len(self.figur[0])/2)
		self.figur_y = 0
		g+=1
		if check_collision(self.doska,
		                   self.figur,
		                   (self.figur_x, self.figur_y)):
			self.gameover = True
	
	def init_game(self):
		self.doska = new_doska()
		self.new_figur()
	
	def center_msg(self, msg):
		for i, line in enumerate(msg.splitlines()):
			msg_image =  pygame.font.Font(
				pygame.font.get_default_font(), 12).render(
					line, False, (255,255,255), (0,0,0))
		
			msgcer_x, msgcer_y = msg_image.get_size()
			msgcer_x //= 2
			msgcer_y //= 2			
		
			self.screen.blit(msg_image, (
			  self.width // 2-msgcer_x,
			  self.height // 2-msgcer_y+i*22))
			
	def right_msg(self, msg):
		for i, line in enumerate(msg.splitlines()):
			msg_image =  pygame.font.Font(
				pygame.font.get_default_font(), 12).render(
					line, False, (255,255,255), (0,0,0))
		
			msgcer_x, msgcer_y = msg_image.get_size()
			msgcer_x //= 4
			msgcer_y //= 4
		
			self.screen.blit(msg_image, (
			  self.width // 10-msgcer_x,
			  self.height // 13-msgcer_y+i*22))	
	def up_msg(self, msg):
		for i, line in enumerate(msg.splitlines()):
			msg_image =  pygame.font.Font(
				pygame.font.get_default_font(), 12).render(
					line, False, (255,255,255), (0,0,0))
		
			msgcer_x, msgcer_y = msg_image.get_size()
			msgcer_x //= 4
			msgcer_y //= 4
		
			self.screen.blit(msg_image, (
			  self.width // 4-msgcer_x,
			  self.height // 13-msgcer_y+i*22))		
	
	def draw_matrix(self, matrix, ofset):
		of_x, of_y  = ofset
		for y, row in enumerate(matrix):
			for x, val in enumerate(row):
				if val:
					pygame.draw.rect(
						self.screen,
						colors[val],
						pygame.Rect(
							(of_x+x) *
							  config['cell_size'],
							(of_y+y) *
							  config['cell_size'], 
							config['cell_size'],
							config['cell_size']),0)
					self.right_msg(str(g))
	
	def move(self, delta_x):
		if not self.gameover and not self.paused:
			new_x = self.figur_x + delta_x
			if new_x < 0:
				new_x = 0
			if new_x > config['cols'] - len(self.figur[0]):
				new_x = config['cols'] - len(self.figur[0])
			if not check_collision(self.doska,
			                       self.figur,
			                       (new_x, self.figur_y)):
				self.figur_x = new_x
	def quit(self):
		self.center_msg("Exiting...")
		self.right_msg(str(g))
		pygame.display.update()
		pygame.quit()
	
	def drop(self):
		global g
		if not self.gameover and not self.paused:
			self.figur_y += 1
			if check_collision(self.doska,
			                   self.figur,
			                   (self.figur_x, self.figur_y)):
				self.doska = join_matrixes(
				  self.doska,
				  self.figur,
				  (self.figur_x, self.figur_y))
				self.new_figur()
				while True:
					for i, row in enumerate(self.doska[:-1]):
						if 0 not in row:
							self.doska = remove_row(
							  self.doska, i)
							g+=100
							break
					else:
						break
	
	def rotate_figur(self):
		if not self.gameover and not self.paused:
			new_figur = rotate_clockwise(self.figur)
			if not check_collision(self.doska, new_figur,
			                       (self.figur_x, self.figur_y)):
				self.figur = new_figur
	
	def toggle_pause(self):
		self.paused = not self.paused
	
	def start_game(self):
		global g
		if self.gameover:
			self.init_game()
			self.gameover = False
			g = 0
	
	def run(self):
		global g
		key_actions = {
			'ESCAPE': self.quit,
			'LEFT': lambda:self.move(-1),
			'RIGHT': lambda:self.move(+1),
			'DOWN':	self.drop,
			'UP': self.rotate_figur,
			'p': self.toggle_pause,
			'SPACE': self.start_game,
		        'w': self.rotate_figur,
		        's': self.drop,
		        'd': lambda:self.move(+1),
		        'a': lambda:self.move(-1),
		}
		
		self.gameover = False
		self.paused = False
		
		pygame.time.set_timer(pygame.USEREVENT+1, config['delay'])
		cputime = pygame.time.Clock()
		while 1:
			self.screen.fill((0,0,0))
			if self.gameover:
				self.center_msg("""Game Over!
Press space to continue""")
				self.up_msg("Your score: "+ str(g))
				
			        
			else:
				if self.paused:
					self.center_msg("Paused")
					self.up_msg("Your score: "+ str(g))
				else:
					self.draw_matrix(self.doska, (0,0))
					self.draw_matrix(self.figur, (self.figur_x, self.figur_y))
			pygame.display.update()
			for event in pygame.event.get():
				if event.type == pygame.USEREVENT+1:
					self.drop()
				elif event.type == pygame.QUIT:
					self.quit()
				elif event.type == pygame.KEYDOWN:
					for key in key_actions:
						if event.key == eval("pygame.K_"+key):
							key_actions[key]()
							
			cputime.tick(config['maxfps'])
			
if __name__ == '__main__':
	pygame.init()
	pygame.mixer.music.load('Test.mp3')
	pygame.mixer.music.play()	
	App = TetrisApp()
	App.run()
